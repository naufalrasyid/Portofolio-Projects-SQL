CREATE DATABASE tiket_konser_2021;
DROP DATABASE tiket_konser_2021;
CREATE DATABASE tiket_konser_2022;

USE tiket_konser_2022;

CREATE TABLE pembeli
	(
		id_pembeli INT PRIMARY KEY NOT NULL,
        nama_pembeli VARCHAR (50) NOT NULL,
        email_pembeli VARCHAR (50) NOT NULL,
        nomor_tlp CHAR (13) NOT NULL
	);
    
CREATE TABLE tiket
	(
		id_tiket INT PRIMARY KEY NOT NULL,
		nama_konser VARCHAR (30) NOT NULL,
        nama_pembeli VARCHAR (50) NOT NULL,
        tipe_tiket CHAR (10) NOT NULL,
        show_date DATE NOT NULL,
        show_time TIME NOT NULL
	);

CREATE TABLE tipe_tiket
	(
		id_tipe INT PRIMARY KEY NOT NULL,
        tipe CHAR (10) NOT NULL,
		harga_tiket FLOAT NOT NULL
	);
    
CREATE TABLE transaksi
	(
		id_transaksi INT PRIMARY KEY NOT NULL,
        tgl_transaksi DATE,
        id_pembeli INT NOT NULL,
        tipe CHAR(10) NOT NULL,
        qty_tiket INT NOT NULL,
		harga_tiket FLOAT NOT NULL,
        total_harga_tiket FLOAT NOT NULL
	);
    

        
        
        