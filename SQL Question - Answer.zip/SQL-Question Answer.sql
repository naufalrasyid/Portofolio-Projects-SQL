CREATE DATABASE  IF NOT EXISTS `binus_university_management_system_2023` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `binus_university_management_system_2023`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: binus_university_management_system_2023
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mahasiswa`
--

DROP TABLE IF EXISTS `mahasiswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mahasiswa` (
  `id_mahasiswa` int NOT NULL AUTO_INCREMENT,
  `nama_mahasiswa` varchar(30) NOT NULL,
  `alamat_mahasiswa` varchar(25) NOT NULL,
  `kota` varchar(10) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `usia` int NOT NULL,
  `no_kontak` int NOT NULL,
  `email` varchar(30) NOT NULL,
  `jurusan` char(3) NOT NULL,
  `nama_wali` varchar(30) NOT NULL,
  `tgl_terdaftar` date NOT NULL,
  `prestasi_1` varchar(30) DEFAULT NULL,
  `prestasi_2` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_mahasiswa`),
  KEY `IDX_mahasiswa` (`nama_mahasiswa`,`jurusan`,`tgl_lahir`)
) ENGINE=InnoDB AUTO_INCREMENT=2509 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mata_kuliah`
--

DROP TABLE IF EXISTS `mata_kuliah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mata_kuliah` (
  `id_mata_kuliah` varchar(15) NOT NULL,
  `nama_mata_kuliah` varchar(30) NOT NULL,
  `jurusan` char(3) NOT NULL,
  `kelas` varchar(5) NOT NULL,
  `tahun_ajaran` int NOT NULL,
  `semester` int NOT NULL,
  `jenis` char(3) NOT NULL,
  `kode_dosen` varchar(7) NOT NULL,
  `nama_dosen` varchar(30) NOT NULL,
  `kuota_maks` int NOT NULL,
  `kuota_tersisa` int NOT NULL,
  `model_perkuliahan` varchar(20) NOT NULL,
  `status_` varchar(10) NOT NULL,
  `durasi` varchar(3) DEFAULT NULL,
  `maks_sks` int NOT NULL,
  PRIMARY KEY (`id_mata_kuliah`),
  KEY `IDX_mata_kuliah` (`nama_mata_kuliah`,`jurusan`,`jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pegawai`
--

DROP TABLE IF EXISTS `pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pegawai` (
  `id_pegawai` int NOT NULL AUTO_INCREMENT,
  `nama_pegawai` varchar(30) NOT NULL,
  `pemberian_pelaporan_kepada` int DEFAULT NULL,
  PRIMARY KEY (`id_pegawai`),
  KEY `pemberian_pelaporan_kepada` (`pemberian_pelaporan_kepada`),
  CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`pemberian_pelaporan_kepada`) REFERENCES `pegawai` (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=1206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi` (
  `id_transaksi` int NOT NULL AUTO_INCREMENT,
  `id_mahasiswa` int NOT NULL,
  `id_mata_kuliah` varchar(15) NOT NULL,
  `jurusan` char(3) NOT NULL,
  `timestamp_transaksi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `jumlah_sks` int NOT NULL,
  `total_biaya` int NOT NULL,
  `virtual_account` int NOT NULL,
  `status_pembayaran` varchar(13) NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `potongan_biaya` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_mahasiswa` (`id_mahasiswa`),
  KEY `id_mata_kuliah` (`id_mata_kuliah`),
  CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_mahasiswa`) REFERENCES `mahasiswa` (`id_mahasiswa`),
  CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_mata_kuliah`) REFERENCES `mata_kuliah` (`id_mata_kuliah`)
) ENGINE=InnoDB AUTO_INCREMENT=1411 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-19  0:43:32
